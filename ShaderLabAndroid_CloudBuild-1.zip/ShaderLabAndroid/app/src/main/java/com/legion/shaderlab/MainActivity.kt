package com.legion.shaderlab

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Canvas
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.security.MessageDigest
import java.util.Locale
import kotlin.math.roundToInt

private val Bg = Color(0xFF15171D)
private val Panel = Color(0xFF232733)
private val Accent = Color(0xFFBCC8FF)
private val Muted = Color(0xFF9299AA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShaderLabApp(contentResolver) }
    }
}

@Composable
fun ShaderLabApp(resolver: ContentResolver) {
    var tab by remember { mutableIntStateOf(1) }
    var fileName by remember { mutableStateOf("Файл не выбран") }
    var fileInfo by remember { mutableStateOf("Выбери файл для анализа") }
    var hexDump by remember { mutableStateOf("") }
    var log by remember { mutableStateOf("Готово. Оригиналы не перезаписываются.") }
    var saturation by remember { mutableFloatStateOf(1.35f) }
    var contrast by remember { mutableFloatStateOf(1.08f) }
    var brightness by remember { mutableFloatStateOf(1.0f) }
    var red by remember { mutableFloatStateOf(0.15f) }
    var green by remember { mutableFloatStateOf(1.0f) }
    var blue by remember { mutableFloatStateOf(0.12f) }
    var tintEnabled by remember { mutableStateOf(false) }
    var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var gradedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var shaderText by remember { mutableStateOf("""// ShaderLab GLSL playground
// Educational sample: color a material in your own test scene.
precision mediump float;
uniform vec4 uColor;
void main() {
    gl_FragColor = uColor;
}
""".trimIndent()) }

    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val bytes = resolver.openInputStream(uri)?.use { it.readNBytes(1024 * 1024) } ?: byteArrayOf()
                fileName = queryName(resolver, uri)
                val digest = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
                hexDump = bytes.take(512).chunked(16).mapIndexed { index, row ->
                    val offset = "%08X".format(index * 16)
                    val hex = row.joinToString(" ") { "%02X".format(it) }.padEnd(47, ' ')
                    val ascii = row.joinToString("") { b ->
                        val n = b.toInt() and 255
                        if (n in 32..126) n.toChar().toString() else "."
                    }
                    "$offset  $hex  $ascii"
                }.joinToString("\n")
                fileInfo = "Прочитано ${bytes.size} байт (макс. 1 МБ)\nSHA-256 фрагмента: $digest"
                log = "Проанализирован файл: $fileName"
            } catch (e: Exception) {
                fileInfo = "Ошибка чтения: ${e.message}"
                log = "Ошибка чтения файла"
            }
        }
    }
    val openImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) try {
            sourceBitmap = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            gradedBitmap = sourceBitmap?.let { gradeBitmap(it, saturation, contrast, brightness, tintEnabled, red, green, blue) }
            log = "Изображение загружено для цветокоррекции"
        } catch (e: Exception) { log = "Не удалось открыть изображение: ${e.message}" }
    }
    val saveImage = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null && gradedBitmap != null) try {
            resolver.openOutputStream(uri)?.use { gradedBitmap!!.compress(Bitmap.CompressFormat.PNG, 100, it) }
            log = "Цветокоррекция сохранена в PNG"
        } catch (e: Exception) { log = "Ошибка сохранения изображения" }
    }
    val saveText = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) try {
            resolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(shaderText) }
            log = "Текстовый файл сохранён"
        } catch (e: Exception) { log = "Ошибка сохранения" }
    }
    val saveProfile = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) try {
            val json = """{"saturation":$saturation,"contrast":$contrast,"brightness":$brightness,"tintEnabled":$tintEnabled,"red":$red,"green":$green,"blue":$blue}"""
            resolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(json) }
            log = "Цветовой профиль экспортирован"
        } catch (e: Exception) { log = "Ошибка экспорта профиля" }
    }

    LaunchedEffect(saturation, contrast, brightness, tintEnabled, red, green, blue, sourceBitmap) {
        gradedBitmap = sourceBitmap?.let { gradeBitmap(it, saturation, contrast, brightness, tintEnabled, red, green, blue) }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onPrimary = Color(0xFF15171D), onBackground = Color(0xFFE9EBF4),
        onSurface = Color(0xFFE9EBF4), secondary = Muted
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Accent) {
                NavigationBarItem(tab == 0, { tab = 0 }, icon = { Text("▤", fontSize = 22.sp) }, label = { Text("Файлы") })
                NavigationBarItem(tab == 1, { tab = 1 }, icon = { Text("⌂", fontSize = 22.sp) }, label = { Text("Цвет") })
                NavigationBarItem(tab == 2, { tab = 2 }, icon = { Text("◇", fontSize = 22.sp) }, label = { Text("GLSL") })
                NavigationBarItem(tab == 3, { tab = 3 }, icon = { Text("⚙", fontSize = 22.sp) }, label = { Text("Ещё") })
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Shader Compiler", fontSize = 29.sp, fontWeight = FontWeight.Medium)
                when (tab) {
                    0 -> {
                        Section("БИНАРНЫЙ АНАЛИЗ") {
                            Button(onClick = { openFile.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Открыть файл") }
                            Text(fileName, color = Accent)
                            Text(fileInfo, color = Muted, fontSize = 12.sp)
                            Text("HEX / ASCII • первые 512 байт", fontWeight = FontWeight.SemiBold)
                            Text(hexDump.ifBlank { "Выбери файл, чтобы увидеть байты." }, fontSize = 10.sp, lineHeight = 14.sp, color = Color(0xFFD1D7EE))
                            Text("Просмотр безопасный: оригинал не меняется. Редактирование байтов можно добавить отдельным шагом после проверки формата.",
                                color = Muted, fontSize = 12.sp)
                        }
                    }
                    1 -> {
                        Section("ЦВЕТОКОРРЕКЦИЯ") {
                            Text("Загрузи скриншот или изображение, настрой цвета и сохрани результат.")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { openImage.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("Открыть") }
                                OutlinedButton(onClick = { saveProfile.launch("shaderlab-profile.json") }, modifier = Modifier.weight(1f)) { Text("Экспорт профиля") }
                            }
                            GradeSlider("Насыщенность", saturation, 0f, 2.5f) { saturation = it }
                            GradeSlider("Контраст", contrast, 0.5f, 1.8f) { contrast = it }
                            GradeSlider("Яркость", brightness, 0.5f, 1.5f) { brightness = it }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("RGB-тонирование", Modifier.weight(1f))
                                Switch(tintEnabled, { tintEnabled = it })
                            }
                            if (tintEnabled) {
                                GradeSlider("Красный", red, 0f, 1f) { red = it }
                                GradeSlider("Зелёный", green, 0f, 1f) { green = it }
                                GradeSlider("Синий", blue, 0f, 1f) { blue = it }
                            }
                            gradedBitmap?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 320.dp)) }
                            if (gradedBitmap != null) Button(onClick = { saveImage.launch("shaderlab-colorgraded.png") }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить PNG") }
                            Text("Важно: это фильтр для выбранного изображения, а не цветовой фильтр поверх Standoff 2. Он не меняет цвета игроков внутри игры.",
                                color = Muted, fontSize = 12.sp)
                        }
                        Section("ДОСТУПНОСТЬ") {
                            Text("Для лучшей различимости попробуй повышенную насыщенность и контраст. Для изменения изображения в реальном времени используй доступные настройки цвета/контраста телефона и игровые настройки.")
                        }
                    }
                    2 -> {
                        Section("РЕДАКТОР GLSL") {
                            Text("Редактор исходного текста шейдера для собственной тестовой сцены. Синтаксис пока не компилируется внутри приложения.")
                            OutlinedTextField(
                                value = shaderText, onValueChange = { shaderText = it },
                                modifier = Modifier.fillMaxWidth().height(300.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color(0xFFE5E9FF), unfocusedTextColor = Color(0xFFE5E9FF),
                                    focusedBorderColor = Accent, unfocusedBorderColor = Muted
                                )
                            )
                            Button(onClick = { saveText.launch("shader.frag") }, modifier = Modifier.fillMaxWidth()) { Text("Экспортировать .frag/.txt") }
                            OutlinedButton(onClick = {
                                shaderText = """precision mediump float;
uniform vec4 uColor;
void main() {
    gl_FragColor = uColor;
}"""
                                log = "Загружен пример GLSL"
                            }, modifier = Modifier.fillMaxWidth()) { Text("Вернуть пример GLSL") }
                        }
                    }
                    else -> {
                        Section("ИНСТРУМЕНТЫ") {
                            Text("ShaderLab 1.1 • без root")
                            Text("• HEX/ASCII просмотр\n• SHA-256\n• Цветокоррекция изображений\n• Экспорт PNG\n• Экспорт JSON-профилей\n• Редактор и экспорт GLSL")
                            Text("Журнал", fontWeight = FontWeight.SemiBold)
                            Text(log, color = Muted, fontSize = 13.sp)
                            OutlinedButton(onClick = { log = "Журнал очищен" }, modifier = Modifier.fillMaxWidth()) { Text("Очистить журнал") }
                        }
                        Section("ОБ ОГРАНИЧЕНИЯХ") {
                            Text("Приложение не патчит Standoff 2 и не перекрашивает игроков в самой игре. Это редактор файлов, цветокоррекции изображений и учебных шейдеров.", color = Muted, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

private fun queryName(resolver: ContentResolver, uri: Uri): String {
    return resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) ?: (uri.lastPathSegment ?: "file") else "file"
    } ?: (uri.lastPathSegment ?: "file")
}

private fun gradeBitmap(src: Bitmap, saturation: Float, contrast: Float, brightness: Float,
                        tintEnabled: Boolean, r: Float, g: Float, b: Float): Bitmap {
    val sat = ColorMatrix().apply { setSaturation(saturation) }
    val c = contrast
    val offset = 128f * (1f - c)
    val matrix = ColorMatrix(floatArrayOf(
        c,0f,0f,0f,offset, 0f,c,0f,0f,offset, 0f,0f,c,0f,offset, 0f,0f,0f,1f,0f
    ))
    sat.postConcat(matrix)
    val tint = if (tintEnabled) ColorMatrix(floatArrayOf(
        r,0f,0f,0f,0f, 0f,g,0f,0f,0f, 0f,0f,b,0f,0f, 0f,0f,0f,1f,0f
    )) else ColorMatrix()
    sat.postConcat(tint)
    val bright = ColorMatrix(floatArrayOf(
        brightness,0f,0f,0f,0f, 0f,brightness,0f,0f,0f, 0f,0f,brightness,0f,0f, 0f,0f,0f,1f,0f
    ))
    sat.postConcat(bright)
    val output = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
    Canvas(output).drawBitmap(src, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(sat) })
    return output
}

@Composable
private fun GradeSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Column {
        Text("$label: ${String.format(Locale.US, "%.2f", value)}×")
        Slider(value, onChange, valueRange = min..max)
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, color = Accent, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
            content()
        }
    }
}
